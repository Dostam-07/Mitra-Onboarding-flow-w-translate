import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, UserRound, Phone } from 'lucide-react';
import { translations, type Language } from '../translations';

interface ProfileStepProps {
  onNext: (data: { phone: string; name: string; language: string }) => void;
  initialLanguage?: Language;
  onLanguageChange?: (l: Language) => void;
  initialName?: string;
  initialPhone?: string;
}

export function ProfileStep({ onNext, initialLanguage = 'English', onLanguageChange, initialName = '', initialPhone = '' }: ProfileStepProps) {
  const [phone, setPhone] = useState(initialPhone.replace(/\D/g, '').slice(-10));
  const [name, setName] = useState(initialName);
  const [error, setError] = useState('');

  const t = translations[initialLanguage];

  const handleContinue = () => {
    if (phone.length !== 10 || !/^\d+$/.test(phone)) {
      setError(t.error_phone);
      return;
    }
    if (name.trim().length < 2) {
      setError(t.error_name);
      return;
    }
    onNext({ phone: `+91 ${phone}`, name: name.trim(), language: initialLanguage });
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex h-full w-full flex-col lg:grid lg:grid-cols-1">
      <div className="flex flex-1 flex-col gap-6 px-6 py-8 md:px-10 md:py-10 lg:px-12 lg:py-12">
        <div className="max-w-xl space-y-4">
          <div className="inline-flex items-center gap-2 rounded-full border border-[#572e91]/10 bg-[#572e91]/6 px-4 py-2 text-xs font-semibold uppercase tracking-[0.26em] text-[#572e91]">
            Step 1 · Profile
          </div>
          <div className="space-y-3">
            <h1 className="text-3xl font-semibold tracking-tight text-[#1f1630] md:text-4xl">{t.welcome}</h1>
            <p className="max-w-md text-sm leading-6 text-gray-600 md:text-base">{t.start_journey}</p>
          </div>
        </div>

        <div className="max-w-xl space-y-5">
          <div className="space-y-2">
            <label className="flex items-center gap-2 px-1 text-[10px] font-semibold uppercase tracking-[0.28em] text-[#572e91]/60">
              <UserRound size={13} />
              {t.full_name}
            </label>
            <input
              type="text"
              placeholder={t.name_placeholder}
              className="h-14 w-full rounded-[22px] border border-[#572e91]/10 bg-white px-5 text-base font-medium text-gray-900 outline-none transition placeholder:text-gray-400 focus:border-[#572e91]/40 focus:ring-4 focus:ring-[#572e91]/10"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (error) setError('');
              }}
            />
          </div>

          <div className="space-y-2">
            <label className="flex items-center gap-2 px-1 text-[10px] font-semibold uppercase tracking-[0.28em] text-[#572e91]/60">
              <Phone size={13} />
              {t.phone_number}
            </label>
            <div className="flex h-14 items-center gap-3 rounded-[22px] border border-[#572e91]/10 bg-white px-5 focus-within:border-[#572e91]/40 focus-within:ring-4 focus-within:ring-[#572e91]/10">
              <span className="rounded-full bg-[#f3ecfb] px-3 py-1 text-sm font-semibold text-[#572e91]">+91</span>
              <input
                type="tel"
                placeholder="00000 00000"
                className="w-full bg-transparent text-base font-medium tracking-wide text-gray-900 outline-none placeholder:text-gray-400"
                value={phone}
                onChange={(e) => {
                  const val = e.target.value.replace(/\D/g, '').slice(0, 10);
                  setPhone(val);
                  if (error) setError('');
                }}
              />
            </div>
          </div>

          {error && <p className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">{error}</p>}
        </div>

        <div className="mt-auto flex flex-col gap-3 border-t border-[#572e91]/8 pt-5 sm:flex-row sm:items-center sm:justify-between">
          <button
            onClick={() => onLanguageChange?.(initialLanguage)}
            className="hidden rounded-full border border-[#572e91]/10 bg-white px-4 py-2 text-xs font-semibold uppercase tracking-[0.22em] text-gray-500 shadow-sm"
          >
            {t.languages[initialLanguage]}
          </button>
          <button
            onClick={handleContinue}
            className="inline-flex h-16 w-full items-center justify-center gap-2 rounded-full bg-[#572e91] px-6 text-base font-semibold text-white shadow-[0_18px_36px_-18px_rgba(87,46,145,0.7)] transition hover:bg-[#452475] active:translate-y-0 sm:w-auto sm:min-w-[260px]"
          >
            {t.continue}
            <ArrowRight size={18} />
          </button>
        </div>
      </div>
    </motion.div>
  );
}
