import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Send,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  FileDown,
  Loader2,
  User,
  Bot,
  ArrowLeft
} from 'lucide-react';
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import { cn } from '../lib/utils';
import { type Language, translations } from '../translations';
import { type OnboardingState } from '../types';

interface Message {
  id: string;
  text: string;
  sender: 'bot' | 'user';
  timestamp: number;
}

interface ChatStepProps {
  state: OnboardingState;
  language: Language;
  onBack: () => void;
  onFinish: () => void;
}

interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
  resultIndex: number;
}

interface SpeechRecognition extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onresult: (event: SpeechRecognitionEvent) => void;
  onerror: (event: any) => void;
  onend: () => void;
}

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export default function ChatStep({ state, language, onBack, onFinish }: ChatStepProps) {
  const t = translations[language];
  const questions = state.flowType === 'discussion' ? (t.chat_questions_discussion as string[]) : (t.chat_questions_improvement as string[]);

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', text: questions[0], sender: 'bot', timestamp: Date.now() }
  ]);
  const [inputText, setInputText] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isMuted, setIsMuted] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isFinished, setIsFinished] = useState(false);

  const scrollRef = useRef<HTMLDivElement>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [messages]);

  useEffect(() => {
    if (messages.length === 1 && !isMuted) speak(messages[0].text);
  }, []);

  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = language === 'English' ? 'en-US' : language === 'Hindi' ? 'hi-IN' : 'kn-IN';
      recognition.onresult = (event: SpeechRecognitionEvent) => {
        const transcript = event.results[0][0].transcript;
        setInputText(transcript);
        setIsListening(false);
      };
      recognition.onerror = () => setIsListening(false);
      recognition.onend = () => setIsListening(false);
      recognitionRef.current = recognition;
    }
  }, [language]);

  const speak = (text: string) => {
    if (isMuted) return;
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language === 'English' ? 'en-US' : language === 'Hindi' ? 'hi-IN' : 'kn-IN';
    window.speechSynthesis.speak(utterance);
  };

  const toggleListening = () => {
    if (isListening) recognitionRef.current?.stop();
    else {
      recognitionRef.current?.start();
      setIsListening(true);
    }
  };

  const handleSendMessage = () => {
    if (!inputText.trim()) return;
    const userMessage: Message = { id: Date.now().toString(), text: inputText, sender: 'user', timestamp: Date.now() };
    setMessages((prev) => [...prev, userMessage]);
    setInputText('');

    const nextIndex = currentQuestionIndex + 1;
    if (nextIndex < questions.length) {
      setTimeout(() => {
        const botMessage: Message = { id: (Date.now() + 1).toString(), text: questions[nextIndex], sender: 'bot', timestamp: Date.now() };
        setMessages((prev) => [...prev, botMessage]);
        setCurrentQuestionIndex(nextIndex);
        speak(questions[nextIndex]);
      }, 450);
    } else {
      setIsFinished(true);
      setTimeout(() => {
        setMessages((prev) => [...prev, { id: 'finished', text: t.chat_finished as string, sender: 'bot', timestamp: Date.now() }]);
        speak(t.chat_finished as string);
      }, 450);
    }
  };

  const generatePdf = async () => {
    setIsGeneratingPdf(true);
    try {
      const doc = new jsPDF() as any;
      doc.setFontSize(20);
      doc.setTextColor(87, 46, 145);
      doc.text('Mitra Field Report', 105, 20, { align: 'center' });
      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.text('User Profile Details', 20, 35);
      const userInfo = [
        ['Name', state.name],
        ['Phone', state.phone],
        ['Organization', state.organization],
        ['Role', state.role],
        ['Location', `${state.location.village}, ${state.location.district}, ${state.location.state}`]
      ];
      doc.autoTable({ startY: 40, head: [['Field', 'Details']], body: userInfo, theme: 'striped', headStyles: { fillColor: [87, 46, 145] } });
      doc.setFontSize(14);
      doc.text(state.flowType === 'discussion' ? 'Discussion Capture' : 'Improvement Story', 20, doc.lastAutoTable.finalY + 15);
      const chatHistory = messages.filter(m => m.id !== 'finished').reduce((acc: any[], m, i, arr) => {
        if (m.sender === 'user') {
          const question = arr[i - 1]?.text || 'N/A';
          acc.push([question, m.text]);
        }
        return acc;
      }, []);
      doc.autoTable({ startY: doc.lastAutoTable.finalY + 20, head: [['Question', 'Response']], body: chatHistory, theme: 'grid', headStyles: { fillColor: [87, 46, 145] }, columnStyles: { 0: { cellWidth: 80 }, 1: { cellWidth: 90 } } });
      doc.save(`Mitra_Report_${state.name.replace(/\s+/g, '_')}_${Date.now()}.pdf`);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="flex h-full w-full flex-col bg-[#fdfcfb]">
      <div className="flex items-center justify-between border-b border-[#572e91]/10 bg-white px-5 py-4">
        <div className="flex items-center gap-3">
          <button onClick={onBack} className="inline-flex h-11 w-11 items-center justify-center rounded-full border border-[#572e91]/10 bg-white text-gray-500 shadow-sm">
            <ArrowLeft size={18} />
          </button>
          <div>
            <h2 className="text-sm font-semibold text-[#1f1630]">{state.flowType === 'discussion' ? t.capture_discussion : t.share_improvement}</h2>
            <p className="text-[11px] text-gray-500">{t.what_to_do_today}</p>
          </div>
        </div>
        <button onClick={() => { setIsMuted(!isMuted); window.speechSynthesis.cancel(); }} className={cn('inline-flex h-11 items-center gap-2 rounded-full px-4 text-sm font-semibold shadow-sm', isMuted ? 'bg-red-50 text-red-500' : 'bg-[#f4ebff] text-[#572e91]')}>
          {isMuted ? <VolumeX size={18} /> : <Volume2 size={18} />}
          {isMuted ? t.unmute : t.mute}
        </button>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto px-5 py-6 md:px-8" style={{ scrollbarWidth: 'none' }}>
        <div className="mx-auto flex w-full max-w-3xl flex-col gap-4">
          <AnimatePresence mode="popLayout">
            {messages.map((msg) => (
              <motion.div key={msg.id} initial={{ opacity: 0, y: 10, scale: 0.98 }} animate={{ opacity: 1, y: 0, scale: 1 }} className={cn('flex', msg.sender === 'user' ? 'justify-end' : 'justify-start')}>
                <div className={cn('flex max-w-[85%] gap-3', msg.sender === 'user' ? 'flex-row-reverse' : 'flex-row')}>
                  <div className={cn('flex h-9 w-9 items-center justify-center rounded-2xl shadow-sm', msg.sender === 'user' ? 'bg-[#572e91] text-white' : 'bg-[#f1e9ff] text-[#572e91]')}>
                    {msg.sender === 'user' ? <User size={16} /> : <Bot size={16} />}
                  </div>
                  <div className={cn('rounded-[22px] px-4 py-3 text-[15px] leading-6 shadow-sm', msg.sender === 'user' ? 'rounded-tr-md bg-[#572e91] text-white' : 'rounded-tl-md border border-[#572e91]/8 bg-white text-[#1f1630]')}>
                    {msg.text}
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          {isFinished && (
            <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} className="mt-4 flex flex-col items-center gap-4 rounded-[28px] border border-white bg-white px-6 py-8 shadow-sm">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 shadow-sm"><FileDown size={28} /></div>
              <button onClick={generatePdf} disabled={isGeneratingPdf} className="inline-flex h-12 items-center gap-3 rounded-full bg-[#572e91] px-5 text-sm font-semibold text-white shadow-[0_14px_30px_-16px_rgba(87,46,145,0.6)] transition hover:bg-[#452475] disabled:bg-gray-300">
                {isGeneratingPdf ? <Loader2 size={18} className="animate-spin" /> : <FileDown size={18} />}
                {isGeneratingPdf ? t.generating_pdf : t.download_pdf}
              </button>
              <button onClick={onFinish} className="text-xs font-semibold uppercase tracking-[0.22em] text-gray-400 transition hover:text-gray-700">{t.register_another}</button>
            </motion.div>
          )}
        </div>
      </div>

      {!isFinished && (
        <div className="border-t border-[#572e91]/10 bg-white px-5 py-4 md:px-8">
          <div className="mx-auto flex w-full max-w-3xl items-center gap-3 rounded-[24px] border border-[#572e91]/10 bg-[#faf7ff] p-2 pl-3 shadow-sm focus-within:ring-4 focus-within:ring-[#572e91]/10">
            <button onClick={toggleListening} className={cn('inline-flex h-12 w-12 items-center justify-center rounded-full shadow-sm', isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-white text-[#572e91]')}>
              {isListening ? <MicOff size={18} /> : <Mic size={18} />}
            </button>
            <input type="text" value={inputText} onChange={(e) => setInputText(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()} placeholder={isListening ? 'Listening…' : (t.type_message as string)} className="min-w-0 flex-1 bg-transparent px-1 text-sm font-medium text-[#1f1630] outline-none placeholder:text-gray-400" />
            <button onClick={handleSendMessage} disabled={!inputText.trim()} className={cn('inline-flex h-12 w-12 items-center justify-center rounded-full transition', inputText.trim() ? 'bg-[#572e91] text-white shadow-sm' : 'bg-gray-200 text-gray-400')}>
              <Send size={18} />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
